#pragma once 
#include "Plane.h"
#include <iostream>
using namespace std;

void Plane::run()
{

	cout << " Plane is running" << endl;
}