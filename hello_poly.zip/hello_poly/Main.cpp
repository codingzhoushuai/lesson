//��̬
#pragma once
#include <iostream>
#include "Vehicle.h"
#include "Car.h"
#include "Plane.h"
using namespace std;
int main() {

	Vehicle v;
	v.run();

	Car c;
	c.run();

	Plane p;
	p.run();

	cin.get();
}


