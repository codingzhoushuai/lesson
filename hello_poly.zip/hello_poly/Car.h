#pragma once
#include "Vehicle.h"

class Car :public Vehicle
{
public:
	virtual void run();

};