#pragma once 
#include "Car.h"
#include <iostream>
using namespace std;

void Car::run()
{

	cout << " Car is running" << endl;
}