#pragma once
#include "Vehicle.h"

class Plane :public Vehicle
{
public:
	virtual void run();

};