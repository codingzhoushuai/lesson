#pragma once 
#include "Vehicle.h"
#include <iostream>
using namespace std;

void Vehicle::run()
{

	cout << " Vehicle is running" << endl;
}
