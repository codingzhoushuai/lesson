#pragma once
class Vehicle
{
public:
	virtual void run();

};
